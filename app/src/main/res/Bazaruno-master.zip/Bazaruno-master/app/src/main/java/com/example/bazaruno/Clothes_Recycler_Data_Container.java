package com.example.bazaruno;

public class Clothes_Recycler_Data_Container {

    String image="";
    String name="";

    Clothes_Recycler_Data_Container()
    {

    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
